package com.hacker.kapilsony.fragments;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ToxicBakery.viewpager.transforms.FlipHorizontalTransformer;
import com.hacker.kapilsony.GlazyCard;
import com.hacker.kapilsony.R;
import com.hacker.kapilsony.Utils;
import com.hacker.kapilsony.adapter.ViewPagerAdapter;
import com.hacker.kapilsony.views.GlazyImageView;

public class GlazyCardFragment extends Fragment {

    private Context mContext;
    private GlazyCard card;
    TabLayout mTabLayout;
    ViewPager viewPager;
    private TextView description;
    private GlazyImageView imgView;
    private ViewPagerAdapter adapter;


    public static GlazyCardFragment newInstance(GlazyCard card) {
        GlazyCardFragment glazyCardFragment = new GlazyCardFragment();
        Bundle args = new Bundle();
        args.putSerializable("glazy_card", card);
        glazyCardFragment.setArguments(args);
        return glazyCardFragment;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        card = (GlazyCard) getArguments().getSerializable("glazy_card");
        mContext = getContext();
    }
    private void createViewPager() {

        adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFrag(TabFragment.getInstance(card.getTabOneDescription()), "Tab 1");
        adapter.addFrag(TabFragment.getInstance(card.getTabTwoDescription()), "Tab 2");
        adapter.addFrag(TabFragment.getInstance(card.getTabThreeDescription()), "Tab 3");
        adapter.addFrag(TabFragment.getInstance(card.getTabFourDescription()), "Tab 3");
        viewPager.setAdapter(adapter);
        viewPager.setPageTransformer(true,new FlipHorizontalTransformer());
    }
    private void addTabs() {

        createNewTabWithIcon("Tab1",R.drawable.ic_tabone_black,0);
        createNewTabWithIcon("Tab2",R.drawable.ic_tabtwo_black,1);
        createNewTabWithIcon("Tab3",R.drawable.ic_tabthree_black,2);
        createNewTabWithIcon("Tab4",R.drawable.ic_tabfour_black,3);
        setTabsSelectedListener();
    }
    void setTabsSelectedListener(){
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                if(tab.getPosition()==0)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabone_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.RED);
                }
                if(tab.getPosition()==1)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabtwo_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.RED);
                }
                if(tab.getPosition()==2)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabthree_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.RED);
                }
                if(tab.getPosition()==3)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabfour_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.RED);
                }





            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if(tab.getPosition()==0)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabone_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.BLACK);
                }
                if(tab.getPosition()==1)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabtwo_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.BLACK);
                }
                if(tab.getPosition()==2)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabthree_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.BLACK);
                }
                if(tab.getPosition()==3)
                {
                    TextView tv = (TextView) tab.getCustomView();
                    tv.setCompoundDrawablesWithIntrinsicBounds(0,R.drawable.ic_tabfour_black,0,0);
                    //tv.setCompoundDrawables(null,getLowImage(R.drawable.ic_one_selected),null,null);
                    tv.setTextColor(Color.BLACK);
                }

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
    void createNewTabWithIcon(String tabname, int icon, int position) {



        TextView tab = (TextView) LayoutInflater.from(getContext()).inflate(R.layout.custom_tabs_view, null);
        tab.setText(tabname);
        if(position==0)
        {
            tab.setTextColor(Color.RED);
        }
        else {
            tab.setTextColor(Color.BLACK);
        }
        tab.setCompoundDrawablesWithIntrinsicBounds(0, icon, 0, 0);
        //tab.setCompoundDrawables(null,getLowImage(icon),null,null);
        //mTabLayout.addTab(mTabLayout.newTab().setText("tab1"));
        mTabLayout.getTabAt(position).setCustomView(tab);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.layout_page, container, false);
        v.setBackgroundColor(card.getBackgroundColor());
        // Kapil Sony
        viewPager = (ViewPager) v.findViewById(R.id.view_pager);
        mTabLayout = (TabLayout) v.findViewById(R.id.tablayout);
        createViewPager();
        mTabLayout.setupWithViewPager(viewPager);
        addTabs();
        /*descriptionFromBundle = (TextView) v.findViewById(R.id.description_text);
        descriptionFromBundle.setText(card.getDescription());
        descriptionFromBundle.setAlpha(0f);*/

        imgView = (GlazyImageView) v.findViewById(R.id.glazy_image_view);
        imgView.setImageRes(card.getImageRes());
        imgView.setTitleText(card.getTitle());
        imgView.setTitleTextColor(card.getTitleColor());
        imgView.setTitleTextSize(Utils.dpToPx(mContext, card.getTitleSizeDP()));
        imgView.setSubTitleText(card.getSubTitle());
        imgView.setSubTitleTextColor(card.getSubTitleColor());
        imgView.setSubTitleTextSize(Utils.dpToPx(mContext, card.getSubTitleSizeDP()));
        imgView.setTextMargin(Utils.dpToPx(mContext, card.getTextmatginDP()));
        imgView.setLineSpacing(Utils.dpToPx(mContext, card.getLineSpacingDP()));
        imgView.setAutoTint(card.isAutoTint());
        imgView.setTintColor(card.getTintColor());
        imgView.setTintAlpha(card.getTintAlpha());
        imgView.setCutType(card.getImageCutType());
        imgView.setCutCount(card.getImageCutCount());
        imgView.setCutHeight(Utils.dpToPx(mContext,card.getImageCutHeightDP()));

        return v;
    }


}
