package com.hacker.kapilsony.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hacker.kapilsony.R;

/**
 * Created by root on 21/6/17.
 */

public class TabFragment extends Fragment {

    String descriptionFromBundle;
    private Context mContext;
    TextView mDataDescription;

    public static TabFragment getInstance(String dataDescription)
    {
        TabFragment tabFragment = new TabFragment();
        Bundle args = new Bundle();
        args.putString("desc",dataDescription);
        tabFragment.setArguments(args);
        return tabFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        descriptionFromBundle =getArguments().getString("desc","Data Not Found");
        mContext=getContext();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.frg_tab_one,container,false);

        mDataDescription= (TextView) view.findViewById(R.id.dataDescription);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mDataDescription.setText(descriptionFromBundle);


    }
}
