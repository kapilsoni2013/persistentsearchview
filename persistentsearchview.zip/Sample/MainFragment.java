package kapilsony.sachtech.com.axshare;

import android.animation.Animator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hacker.kapilsony.persistentsearch.DefaultVoiceRecognizerDelegate;
import com.hacker.kapilsony.persistentsearch.PersistentSearchView;
import com.hacker.kapilsony.persistentsearch.SearchItem;
import com.hacker.kapilsony.persistentsearch.VoiceRecognitionDelegate;

import java.util.ArrayList;

import kapilsony.sachtech.com.axshare.adapter.RecyclerViewAdapter;
import kapilsony.sachtech.com.axshare.adapter.SampleSuggestionsBuilder;
import kapilsony.sachtech.com.axshare.constants.Constants;
import kapilsony.sachtech.com.axshare.utils.SimpleAnimationListener;

/**
 * Created by root on 22/6/17.
 */

public class MainFragment extends Fragment {
    public static String TAG="MainFragment";
    FragmentManager fragmentManager2;
    VoiceRecognitionDelegate delegate;
    private View mSearchTintView;

    RecyclerView mRecyclerView;
    PersistentSearchView mSearchView;
    private RecyclerViewAdapter adapter;
    private int VOICE_RECOGNITION_REQUEST_CODE=44;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.frg_main,container,false);
        initView(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fragmentManager2=getFragmentManager();
        Constants.setData();
        adapter=new RecyclerViewAdapter(getContext(),fragmentManager2, Constants.getData());
        LinearLayoutManager manager=new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.setAdapter(adapter);

        setupSearchView();

    }

    private void setupSearchView() {
        setSearchListener();

        if(delegate.isVoiceRecognitionAvailable())
        {
            mSearchView.setVoiceRecognitionDelegate(delegate);
        }


    }

    private void setSearchListener() {
        mSearchView.setSuggestionBuilder(new SampleSuggestionsBuilder(getContext(),mSearchView));
        mSearchView.setSearchListener(new PersistentSearchView.SearchListener() {

            @Override
            public void onSearchEditOpened() {
                //Use this to tint the screen
                //mSearchTintView.setVisibility(View.VISIBLE);
                mSearchTintView
                        .animate()
                        .alpha(1.0f)
                        .setDuration(300)
                        .setListener(new SimpleAnimationListener())
                        .start();
            }

            @Override
            public void onSearchEditClosed() {
                mSearchTintView
                        .animate()
                        .alpha(0.0f)
                        .setDuration(300)
                        .setListener(new SimpleAnimationListener() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                //mSearchTintView.setVisibility(View.GONE);
                            }
                        })
                        .start();
            }
            @Override
            public boolean onSuggestion(SearchItem searchItem) {
                Log.d("onSuggestion", searchItem.getTitle());
                return false;
            }

            @Override
            public void onSearchCleared() {

            }

            @Override
            public void onSearchTermChanged(String term) {

                Log.d("onSearchTermChanged@&: ",term);
                if(term.isEmpty())
                {
                    adapter.resetDefaultList();
                }
                else
                {
                    adapter.filter(term);
                }

            }

            @Override
            public void onSearch(String query) {
                Log.d("onSearch@$:", query +" Searched");
            }


            @Override
            public boolean onSearchEditBackPressed() {
                return false;
            }

            @Override
            public void onSearchExit() {

            }
        });
    }

    private void initView(View view) {

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerview);
        mSearchView= (PersistentSearchView) view.findViewById(R.id.searchview);
        mSearchTintView = view.findViewById(R.id.view_search_tint);
        delegate=new DefaultVoiceRecognizerDelegate(getActivity(),VOICE_RECOGNITION_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==VOICE_RECOGNITION_REQUEST_CODE && resultCode== Activity.RESULT_OK)
        {
            ArrayList<String> voiceMatches=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            mSearchView.populateEditText(voiceMatches);
        }
    }
}
