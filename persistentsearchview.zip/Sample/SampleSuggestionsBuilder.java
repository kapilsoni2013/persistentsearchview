package kapilsony.sachtech.com.axshare.adapter;

import android.content.Context;

import com.hacker.kapilsony.persistentsearch.PersistentSearchView;
import com.hacker.kapilsony.persistentsearch.SearchItem;
import com.hacker.kapilsony.persistentsearch.SearchSuggestionsBuilder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import kapilsony.sachtech.com.axshare.constants.Constants;
import kapilsony.sachtech.com.axshare.model.ChapterModel;

public class SampleSuggestionsBuilder implements SearchSuggestionsBuilder {
    private Context mContext;
    private List<SearchItem> mHistorySuggestions = new ArrayList<SearchItem>();
    private List<SearchItem> mFilteredList = new ArrayList<SearchItem>();
    PersistentSearchView mSearchView;

    public SampleSuggestionsBuilder(Context context, PersistentSearchView mSearchView) {
        this.mContext = context;
        this.mSearchView=mSearchView;
        setHistoryList();
        //createHistorys();
    }

    private void setHistoryList() {

        mFilteredList.clear();
        ArrayList<ChapterModel> mList = Constants.getData();
        for(int i=0;i<mList.size();i++)
        {
            SearchItem item1 = new SearchItem(
                    mList.get(i).getChapterName(),
                    mList.get(i).getChapterName(),
                    SearchItem.TYPE_SEARCH_ITEM_HISTORY,mSearchView
            );
            mFilteredList.add(item1);
        }
    }

    private void createHistorys() {
        SearchItem item1 = new SearchItem(
                "Isaac Newton",
                "Isaac Newton",
                SearchItem.TYPE_SEARCH_ITEM_HISTORY,mSearchView
        );
        mHistorySuggestions.add(item1);
        SearchItem item2 = new SearchItem(
                "Albert Einstein",
                "Albert Einstein",
                SearchItem.TYPE_SEARCH_ITEM_HISTORY,mSearchView
        );
        mHistorySuggestions.add(item2);
        SearchItem item3 = new SearchItem(
                "John von Neumann",
                "John von Neumann",
                SearchItem.TYPE_SEARCH_ITEM_HISTORY,mSearchView
        );
        mHistorySuggestions.add(item3);
        SearchItem item4 = new SearchItem(
                "Alan Mathison Turing",
                "Alan Mathison Turing",
                SearchItem.TYPE_SEARCH_ITEM_HISTORY,mSearchView
        );
        mHistorySuggestions.add(item4);
    }

    @Override
    public Collection<SearchItem> buildEmptySearchSuggestion(int maxCount) {
        List<SearchItem> items = new ArrayList<SearchItem>();
        //items.addAll(mFilteredList);
        return items;
    }

    @Override
    public Collection<SearchItem> buildSearchSuggestion(int maxCount, String query) {
        List<SearchItem> items = new ArrayList<SearchItem>();

        if(query.startsWith("@")) {
            SearchItem peopleSuggestion = new SearchItem(
                    "Search People: " + query.substring(1),
                    query,
                    SearchItem.TYPE_SEARCH_ITEM_SUGGESTION,mSearchView
            );
            items.add(peopleSuggestion);
        } else if(query.startsWith("#")) {
            SearchItem toppicSuggestion = new SearchItem(
                    "Search Topic: " + query.substring(1),
                    query,
                    SearchItem.TYPE_SEARCH_ITEM_SUGGESTION,mSearchView
            );
            items.add(toppicSuggestion);
        } else {
            SearchItem peopleSuggestion = new SearchItem(
                    "Search Topic: " + query,
                    query,
                    SearchItem.TYPE_SEARCH_ITEM_SUGGESTION,mSearchView
            );
            items.add(peopleSuggestion);
            SearchItem toppicSuggestion = new SearchItem(
                    "Search Topic: " + query,
                    query,
                    SearchItem.TYPE_SEARCH_ITEM_SUGGESTION,mSearchView
            );
            items.add(toppicSuggestion);
        }
        for(SearchItem item : mFilteredList) {
            if(item.getValue().startsWith(query)) {
                items.add(item);
            }
        }
        return items;
    }
}
